/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author lina9
 */
public class Main {
    public static void main(String[] args){
        BookStore bookstore = new BookStore(); // making the bookstore
        bookstore.getAllData(); // getting all necessary data from files
        BookStoreGUI gui = new BookStoreGUI(bookstore);
        gui.setVisible(true); // launch GUI
    }
}
